export type EffectState = 'none' | 'snowflakes' | 'balloons' | 'both';

export interface Snowflake {
  id: string;
  x: number;
  y: number;
  radius: number;
  speedY: number;
  drift: number;
  driftSpeed: number;
  angle: number;
  spin: number;
  opacity: number;
}

export interface Balloon {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  speedY: number;
  color: string;
  opacity: number;
  wobble: number;
  wobbleSpeed: number;
  phase: number;
  stringLength: number;
}
