import { useEffect, useState } from 'react';

interface BackgroundEffectProps {
  activeEffect: 'none' | 'snowflakes' | 'balloons' | 'both';
}

export default function BackgroundEffect({ activeEffect }: BackgroundEffectProps) {
  const [mousePos, setMousePos] = useState({ x: -1000, y: -1000 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  // Determine glow color based on the active atmosphere
  let glowColor = 'rgba(99, 102, 241, 0.07)'; // Indigo default
  if (activeEffect === 'snowflakes') {
    glowColor = 'rgba(14, 165, 233, 0.12)'; // Cyan/Sky blue
  } else if (activeEffect === 'balloons') {
    glowColor = 'rgba(244, 63, 94, 0.1)'; // Pink/Rose
  } else if (activeEffect === 'both') {
    glowColor = 'rgba(168, 85, 247, 0.12)'; // Purple
  }

  return (
    <div id="ambient-background" className="absolute inset-0 overflow-hidden pointer-events-none z-0 bg-slate-950 transition-colors duration-1000">
      {/* Grid Pattern with custom fade */}
      <div 
        id="bg-grid-overlay"
        className="absolute inset-0 opacity-[0.18]"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(255, 255, 255, 0.08) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255, 255, 255, 0.08) 1px, transparent 1px)
          `,
          backgroundSize: '48px 48px',
        }}
      />

      {/* Modern Radial Spotlight (Mouse-reactive) */}
      <div
        id="ambient-spotlight"
        className="absolute inset-0 transition-all duration-300 ease-out"
        style={{
          background: `radial-gradient(700px circle at ${mousePos.x}px ${mousePos.y}px, ${glowColor}, transparent 70%)`,
        }}
      />

      {/* Decorative ambient blurred blobs in background */}
      <div 
        id="ambient-blob-left"
        className={`absolute top-1/4 -left-48 w-[400px] h-[400px] rounded-full blur-[120px] transition-all duration-1000 ${
          activeEffect === 'snowflakes' ? 'bg-sky-500/10' : activeEffect === 'balloons' ? 'bg-rose-500/5' : 'bg-indigo-500/5'
        }`} 
      />
      <div 
        id="ambient-blob-right"
        className={`absolute bottom-1/4 -right-48 w-[400px] h-[400px] rounded-full blur-[120px] transition-all duration-1000 ${
          activeEffect === 'snowflakes' ? 'bg-sky-500/5' : activeEffect === 'balloons' ? 'bg-rose-500/10' : 'bg-rose-500/5'
        }`} 
      />
    </div>
  );
}
