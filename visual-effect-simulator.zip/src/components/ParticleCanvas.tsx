import { useEffect, useRef } from 'react';
import { Snowflake, Balloon } from '../types';

interface ParticleCanvasProps {
  isSpawningSnowflakes: boolean;
  isSpawningBalloons: boolean;
  density: 'light' | 'moderate' | 'abundant';
  speedFactor: number;
  resetTrigger: number;
}

// Fixed luxurious color palettes for balloons
const BALLOON_PALETTES = [
  { base: '#0D9488', shadow: '#0F766E', name: 'Teal Teal' },       // Teal
  { base: '#E11D48', shadow: '#BE123C', name: 'Crimson Rose' },    // Rose/Crimson
  { base: '#7C3AED', shadow: '#6D28D9', name: 'Royal Amethyst' },  // Violet
  { base: '#EA580C', shadow: '#C2410C', name: 'Coral Amber' },     // Orange
  { base: '#D97706', shadow: '#B45309', name: 'Solar Gold' },      // Amber
  { base: '#059669', shadow: '#047857', name: 'Emerald Forest' },  // Emerald
];

export default function ParticleCanvas({
  isSpawningSnowflakes,
  isSpawningBalloons,
  density,
  speedFactor,
  resetTrigger,
}: ParticleCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Use refs for animation variables to prevent high-frequency React re-renders
  const snowflakesRef = useRef<Snowflake[]>([]);
  const balloonsRef = useRef<Balloon[]>([]);
  const animationFrameId = useRef<number | null>(null);
  
  // Track continuous states in refs for read access in requestAnimationFrame
  const isSpawningSnowRef = useRef(isSpawningSnowflakes);
  const isSpawningBalloonsRef = useRef(isSpawningBalloons);
  const densityRef = useRef(density);
  const speedRef = useRef(speedFactor);

  // Reset particles immediately when resetTrigger fires
  useEffect(() => {
    snowflakesRef.current = [];
    balloonsRef.current = [];
  }, [resetTrigger]);

  // Sync props to refs
  useEffect(() => {
    isSpawningSnowRef.current = isSpawningSnowflakes;
  }, [isSpawningSnowflakes]);

  useEffect(() => {
    isSpawningBalloonsRef.current = isSpawningBalloons;
  }, [isSpawningBalloons]);

  useEffect(() => {
    densityRef.current = density;
  }, [density]);

  useEffect(() => {
    speedRef.current = speedFactor;
  }, [speedFactor]);

  // Handle Resize safely using ResizeObserver
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      if (parent) {
        canvas.width = parent.clientWidth;
        canvas.height = parent.clientHeight;
      }
    };

    resizeCanvas();
    const observer = new ResizeObserver(() => resizeCanvas());
    if (canvas.parentElement) {
      observer.observe(canvas.parentElement);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  // Main high-performance render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frameCount = 0;

    const render = () => {
      frameCount++;
      const width = canvas.width;
      const height = canvas.height;

      // Clear standard frame transparently
      ctx.clearRect(0, 0, width, height);

      // 1. SPAWN PARTICLES BASED ON TIMING AND DENSITY
      // Density multipliers
      let snowflakeSpawnInterval = 6; // frame interval
      let balloonSpawnInterval = 14;

      if (densityRef.current === 'light') {
        snowflakeSpawnInterval = 12;
        balloonSpawnInterval = 28;
      } else if (densityRef.current === 'abundant') {
        snowflakeSpawnInterval = 3;
        balloonSpawnInterval = 7;
      }

      // Spawn Snowflakes
      if (isSpawningSnowRef.current && frameCount % snowflakeSpawnInterval === 0) {
        // Medium size: radius between 6.5px and 10.5px (diameter 13px - 21px)
        const radius = 6.5 + Math.random() * 4;
        snowflakesRef.current.push({
          id: `${Date.now()}-${Math.random()}`,
          x: Math.random() * width,
          y: -20, // start above screen
          radius,
          speedY: (1.2 + Math.random() * 1.4) * speedRef.current,
          drift: 0.3 + Math.random() * 0.8,
          driftSpeed: Math.random() * 10,
          angle: Math.random() * Math.PI * 2,
          spin: (Math.random() * 0.02 - 0.01) * speedRef.current,
          opacity: 0.85 + Math.random() * 0.15,
        });
      }

      // Spawn Balloons
      if (isSpawningBalloonsRef.current && frameCount % balloonSpawnInterval === 0) {
        // Medium size: width 24px - 32px, height is proportional (32px - 44px)
        const balloonWidth = 24 + Math.random() * 8;
        const balloonHeight = balloonWidth * (1.25 + Math.random() * 0.1); 
        const palette = BALLOON_PALETTES[Math.floor(Math.random() * BALLOON_PALETTES.length)];

        balloonsRef.current.push({
          id: `${Date.now()}-${Math.random()}`,
          x: Math.random() * (width - 60) + 30, // keep padding from vertical edges
          y: height + 40, // start just below screen
          width: balloonWidth,
          height: balloonHeight,
          speedY: (1.4 + Math.random() * 1.6) * speedRef.current,
          color: palette.base,
          opacity: 0.9 + Math.random() * 0.1,
          wobble: 0.4 + Math.random() * 0.6,
          wobbleSpeed: 0.02 + Math.random() * 0.03,
          phase: Math.random() * Math.PI * 2,
          stringLength: 30 + Math.random() * 10, // length of ribbon trailing balloon
        });
      }

      // 2. UPDATE AND DRAW SNOWFLAKES
      const updatedSnowflakes: Snowflake[] = [];
      for (let i = 0; i < snowflakesRef.current.length; i++) {
        const sf = snowflakesRef.current[i];
        
        // Apply physics
        sf.y += sf.speedY;
        sf.angle += sf.spin;
        // Drift side to side based on sin wave
        sf.x += Math.sin(sf.y / 28 + sf.driftSpeed) * sf.drift;

        // If active spawning is turned off (5s ended), gradually fade them out before hitting bottom
        if (!isSpawningSnowRef.current) {
          sf.opacity -= 0.002; // slow fade
        }

        // Filter out off-screen or faded models
        const isOffScreen = sf.y > height + 20;
        const isFaded = sf.opacity <= 0;
        
        if (!isOffScreen && !isFaded) {
          updatedSnowflakes.push(sf);

          // Draw custom 6-branched structural crystalline snowflake
          ctx.save();
          ctx.translate(sf.x, sf.y);
          ctx.rotate(sf.angle);
          ctx.strokeStyle = `rgba(255, 255, 255, ${sf.opacity})`;
          ctx.lineWidth = Math.max(1, sf.radius / 5);
          ctx.lineCap = 'round';
          
          // Draw the skeletal structure
          for (let b = 0; b < 6; b++) {
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(0, -sf.radius);
            ctx.stroke();

            // Intermediary branching (Chevron shape upwards)
            const branchOffset1 = sf.radius * 0.45;
            const branchLength1 = sf.radius * 0.28;
            ctx.beginPath();
            ctx.moveTo(0, -branchOffset1);
            ctx.lineTo(-branchLength1, -branchOffset1 - branchLength1 * 0.4);
            ctx.moveTo(0, -branchOffset1);
            ctx.lineTo(branchLength1, -branchOffset1 - branchLength1 * 0.4);
            ctx.stroke();

            // Outer smaller branch (Chevron)
            const branchOffset2 = sf.radius * 0.75;
            const branchLength2 = sf.radius * 0.2;
            ctx.beginPath();
            ctx.moveTo(0, -branchOffset2);
            ctx.lineTo(-branchLength2, -branchOffset2 - branchLength2 * 0.4);
            ctx.moveTo(0, -branchOffset2);
            ctx.lineTo(branchLength2, -branchOffset2 - branchLength2 * 0.4);
            ctx.stroke();

            ctx.rotate(Math.PI / 3);
          }

          // Central core aesthetic node
          ctx.beginPath();
          ctx.arc(0, 0, Math.max(1.5, sf.radius / 5.5), 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${sf.opacity * 0.95})`;
          ctx.fill();

          ctx.restore();
        }
      }
      snowflakesRef.current = updatedSnowflakes;

      // 3. UPDATE AND DRAW BALLOONS
      const updatedBalloons: Balloon[] = [];
      for (let i = 0; i < balloonsRef.current.length; i++) {
        const bal = balloonsRef.current[i];

        // Apply rising and wobbling physics
        bal.y -= bal.speedY; // move upwards
        // Oscillation sway mimicking air draft wobble
        bal.phase += bal.wobbleSpeed;
        bal.x += Math.sin(bal.phase) * bal.wobble * 0.7;

        // Fade out slightly if spawn ended to wrap up cleanly
        if (!isSpawningBalloonsRef.current) {
          bal.opacity -= 0.003;
        }

        const isOffScreen = bal.y < - (bal.height + bal.stringLength + 20);
        const isFaded = bal.opacity <= 0;

        if (!isOffScreen && !isFaded) {
          updatedBalloons.push(bal);

          ctx.save();
          ctx.translate(bal.x, bal.y);
          ctx.globalAlpha = bal.opacity;

          // 3a. Draw Balloon Thread/String dangling below
          ctx.beginPath();
          ctx.strokeStyle = `rgba(255, 255, 255, ${0.28 * bal.opacity})`;
          ctx.lineWidth = 1.2;
          ctx.moveTo(0, bal.height / 2);

          // Render wave in string based on sinusoidal movement
          const stringEndX = Math.sin(frameCount * 0.05 + bal.phase) * 6;
          ctx.bezierCurveTo(
            -stringEndX * 1.5, bal.height / 2 + bal.stringLength * 0.35,
            stringEndX * 1.5, bal.height / 2 + bal.stringLength * 0.7,
            stringEndX, bal.height / 2 + bal.stringLength
          );
          ctx.stroke();

          // 3b. Draw Basket/Tie Node (triangular knot at connection point)
          ctx.beginPath();
          ctx.fillStyle = bal.color;
          ctx.moveTo(-3, bal.height / 2 - 1);
          ctx.lineTo(3, bal.height / 2 - 1);
          ctx.lineTo(0, bal.height / 2 + 3);
          ctx.closePath();
          ctx.fill();

          // 3c. Draw Main Spherical Balloon Core (Egg Shape with shading)
          ctx.beginPath();
          ctx.ellipse(0, 0, bal.width / 2, bal.height / 2, 0, 0, Math.PI * 2);
          ctx.closePath();

          // High-fidelity 3D radial shading gradient
          const radialGrad = ctx.createRadialGradient(
            -bal.width * 0.16, -bal.height * 0.16, bal.width * 0.04,
            0, 0, bal.width * 0.55
          );
          radialGrad.addColorStop(0, '#FFFFFF'); // Highlight source
          radialGrad.addColorStop(0.2, bal.color);
          
          // Custom shadow mapping without external functions (darken dynamically by overlaying black)
          radialGrad.addColorStop(1, 'rgba(15, 23, 42, 0.45)'); 
          ctx.fillStyle = radialGrad;
          ctx.fill();

          // Overlay base colored fill to blend shadows beautifully
          ctx.beginPath();
          ctx.ellipse(0, 0, bal.width / 2, bal.height / 2, 0, 0, Math.PI * 2);
          ctx.closePath();
          ctx.fillStyle = bal.color;
          ctx.globalCompositeOperation = 'multiply';
          ctx.fill();
          ctx.globalCompositeOperation = 'source-over'; // restore mode

          // 3d. Draw Glossy Curved Highlight Overlay
          ctx.beginPath();
          ctx.ellipse(
            -bal.width * 0.16, 
            -bal.height * 0.16, 
            bal.width * 0.16, 
            bal.height * 0.14, 
            -Math.PI / 6, 
            0, 
            Math.PI * 2
          );
          ctx.closePath();
          
          const glowGrad = ctx.createRadialGradient(
            -bal.width * 0.16, -bal.height * 0.16, 1,
            -bal.width * 0.16, -bal.height * 0.16, bal.width * 0.16
          );
          glowGrad.addColorStop(0, 'rgba(255, 255, 255, 0.55)');
          glowGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
          ctx.fillStyle = glowGrad;
          ctx.fill();

          ctx.restore();
        }
      }
      balloonsRef.current = updatedBalloons;

      // Keep animation running
      animationFrameId.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="particles-canvas"
      className="absolute inset-0 z-10 pointer-events-none w-full h-full block"
      style={{ mixBlendMode: 'screen' }}
    />
  );
}
