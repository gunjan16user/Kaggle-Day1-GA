import { useState, useEffect } from 'react';
import { Sparkles, Snowflake, Sliders, Play, RotateCcw, Activity } from 'lucide-react';
import BackgroundEffect from './components/BackgroundEffect';
import ParticleCanvas from './components/ParticleCanvas';
import { EffectState } from './types';

export default function App() {
  // Timing state in milliseconds (ranges from 5000 down to 0)
  const [snowflakeTimeLeft, setSnowflakeTimeLeft] = useState<number>(0);
  const [balloonTimeLeft, setBalloonTimeLeft] = useState<number>(0);

  // Environmental configurations
  const [density, setDensity] = useState<'light' | 'moderate' | 'abundant'>('moderate');
  const [speedFactor, setSpeedFactor] = useState<number>(1.0);
  
  // Instant clear flag
  const [resetTrigger, setResetTrigger] = useState<number>(0);

  // Manage countdown timers running smoothly at 20fps (tick every 50ms)
  useEffect(() => {
    if (snowflakeTimeLeft <= 0 && balloonTimeLeft <= 0) return;

    const timer = setInterval(() => {
      setSnowflakeTimeLeft((prev) => Math.max(0, prev - 50));
      setBalloonTimeLeft((prev) => Math.max(0, prev - 50));
    }, 50);

    return () => clearInterval(timer);
  }, [snowflakeTimeLeft > 0, balloonTimeLeft > 0]);

  // Determine current active atmospheric ambient condition
  let activeEffect: EffectState = 'none';
  if (snowflakeTimeLeft > 0 && balloonTimeLeft > 0) {
    activeEffect = 'both';
  } else if (snowflakeTimeLeft > 0) {
    activeEffect = 'snowflakes';
  } else if (balloonTimeLeft > 0) {
    activeEffect = 'balloons';
  }

  // Triggers
  const handleTriggerSnowflakes = () => {
    setSnowflakeTimeLeft(5000); // Trigger a 5.0s burst
  };

  const handleTriggerBalloons = () => {
    setBalloonTimeLeft(5000); // Trigger a 5.0s burst
  };

  const handleResetSimulation = () => {
    setSnowflakeTimeLeft(0);
    setBalloonTimeLeft(0);
    setResetTrigger((prev) => prev + 1); // Signal canvas to instantly wipe
  };

  const isSnowActive = snowflakeTimeLeft > 0;
  const isBalloonActive = balloonTimeLeft > 0;

  // Percentage of timer remaining
  const snowPercent = (snowflakeTimeLeft / 5000) * 100;
  const balloonPercent = (balloonTimeLeft / 5000) * 100;

  return (
    <div 
      id="app-container" 
      className="relative w-screen h-screen flex flex-col justify-between overflow-hidden bg-slate-900 font-sans text-white select-none"
    >
      {/* 1. Mouse-reactive ambient glowing background */}
      <BackgroundEffect activeEffect={activeEffect} />

      {/* 2. High-performance custom HTML5 Canvas particle generator */}
      <ParticleCanvas
        isSpawningSnowflakes={snowflakeTimeLeft > 0}
        isSpawningBalloons={balloonTimeLeft > 0}
        density={density}
        speedFactor={speedFactor}
        resetTrigger={resetTrigger}
      />

      {/* 3. Sleek Navigation Header */}
      <nav id="sleek-nav" className="z-20 px-6 md:px-12 py-6 flex justify-between items-center border-b border-white/10 bg-slate-900/40 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/10">
            <span className="text-xs font-bold text-white">A</span>
          </div>
          <span className="font-outfit font-bold tracking-tight text-lg md:text-xl text-white">
            Atmosphere Studio
          </span>
        </div>
        <div className="flex gap-4 md:gap-8 text-xs font-mono font-medium text-slate-400 uppercase tracking-widest">
          <span className="text-blue-400 border-b-2 border-blue-400 pb-1 cursor-pointer">Live Console</span>
          <span className="hover:text-white transition-colors cursor-pointer hidden sm:inline">Analytics</span>
          <span className="hover:text-white transition-colors cursor-pointer hidden sm:inline">Settings</span>
        </div>
      </nav>

      {/* 4. Main Console Centerpiece */}
      <main id="main-content" className="flex-1 z-20 flex flex-col items-center justify-center px-4 md:px-12 py-8 max-y-full overflow-y-auto">
        <div className="max-w-2xl text-center space-y-4 md:space-y-6 mb-8 md:mb-12">
          <span className="inline-flex items-center gap-1.5 bg-indigo-500/10 border border-indigo-500/30 px-3 py-1 rounded-full text-[10px] font-mono tracking-wider text-indigo-300 uppercase">
            <Sparkles className="w-3 h-3 text-indigo-400 animate-pulse" /> Precision Physics Engine
          </span>
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-slate-400 font-outfit">
            Interactive Environmental Controller
          </h1>
          <p className="text-xs md:text-base text-slate-400 leading-relaxed max-w-xl mx-auto">
            Choose an atmospheric effect below to initiate fluid particle simulation. Each sequence generates high-fidelity physics modules lasting for precisely 5.0 seconds. Use mouse movements to interact with the ambient spotlight.
          </p>
        </div>

        {/* Action Triggers: Sleek Double Buttons with Custom Glowing Ambient Borders */}
        <div id="glow-triggers-grid" className="flex flex-col sm:flex-row gap-6 md:gap-8 justify-center items-center w-full max-w-2xl px-4">
          
          {/* Snowflakes Button */}
          <div className="group relative w-full sm:w-64">
            <div className={`absolute -inset-1 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-2xl blur transition duration-500 ${
              isSnowActive ? 'opacity-70 scale-102' : 'opacity-20 group-hover:opacity-50'
            }`} />
            <button 
              id="snowflake-interactive-btn"
              onClick={handleTriggerSnowflakes}
              className={`relative w-full px-8 py-6 rounded-xl flex flex-col items-center gap-4 border transition-all duration-300 select-none overflow-hidden cursor-pointer ${
                isSnowActive 
                  ? 'bg-slate-900/90 border-cyan-400/80 text-white shadow-[inset_0_0_12px_rgba(6,182,212,0.15)]' 
                  : 'bg-slate-800/90 hover:bg-slate-800 border-white/10 hover:border-white/20 text-slate-300 hover:text-white'
              }`}
            >
              {/* Active countdown progression background shimmer */}
              {isSnowActive && (
                <div 
                  className="absolute left-0 bottom-0 h-1.5 bg-gradient-to-r from-cyan-400 to-blue-500 transition-all ease-linear"
                  style={{ width: `${snowPercent}%` }}
                />
              )}
              
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center transition-all ${
                isSnowActive ? 'bg-cyan-500/20 text-cyan-300 animate-spin-slow' : 'text-cyan-400 opacity-80'
              }`}>
                <Snowflake className="w-8 h-8" />
              </div>

              <div className="text-center">
                <span className="text-lg font-bold tracking-wide block font-outfit">Snowflakes</span>
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono mt-1 block">
                  {isSnowActive ? `Simulating (${(snowflakeTimeLeft / 1000).toFixed(1)}s)` : 'Simulate Winter'}
                </span>
              </div>
            </button>
          </div>

          {/* Balloons Button */}
          <div className="group relative w-full sm:w-64">
            <div className={`absolute -inset-1 bg-gradient-to-r from-pink-500 to-rose-400 rounded-2xl blur transition duration-500 ${
              isBalloonActive ? 'opacity-70 scale-102' : 'opacity-20 group-hover:opacity-50'
            }`} />
            <button 
              id="balloon-interactive-btn"
              onClick={handleTriggerBalloons}
              className={`relative w-full px-8 py-6 rounded-xl flex flex-col items-center gap-4 border transition-all duration-300 select-none overflow-hidden cursor-pointer ${
                isBalloonActive 
                  ? 'bg-slate-900/90 border-rose-400/80 text-white shadow-[inset_0_0_12px_rgba(244,63,94,0.15)]' 
                  : 'bg-slate-800/90 hover:bg-slate-800 border-white/10 hover:border-white/20 text-slate-300 hover:text-white'
              }`}
            >
              {/* Active countdown progression background shimmer */}
              {isBalloonActive && (
                <div 
                  className="absolute left-0 bottom-0 h-1.5 bg-gradient-to-r from-pink-500 to-rose-400 transition-all ease-linear"
                  style={{ width: `${balloonPercent}%` }}
                />
              )}

              <div className={`w-12 h-12 rounded-lg flex items-center justify-center transition-all ${
                isBalloonActive ? 'bg-rose-500/20 text-rose-300 -translate-y-1' : 'text-rose-400 opacity-80'
              }`}>
                <Sparkles className="w-8 h-8" />
              </div>

              <div className="text-center">
                <span className="text-lg font-bold tracking-wide block font-outfit">Balloons</span>
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono mt-1 block">
                  {isBalloonActive ? `Simulating (${(balloonTimeLeft / 1000).toFixed(1)}s)` : 'Simulate Festive'}
                </span>
              </div>
            </button>
          </div>

        </div>

        {/* Integrated Real-time Tweaking Controls (Density & Velocity) in Sleek Layout */}
        <div id="integrated-settings" className="w-full max-w-xl mt-8 bg-white/5 border border-white/10 rounded-2xl p-5 md:p-6 space-y-4">
          
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-mono font-bold tracking-wider uppercase text-slate-300">
                Atmospheric Modifiers
              </span>
            </div>
            
            <button 
              id="reset-ambient-btn"
              onClick={handleResetSimulation}
              title="Reset Sandbox"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/5 hover:bg-white/10 text-[10px] font-mono text-slate-400 hover:text-rose-400 border border-white/10 transition-all cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" /> Clear Frame
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Control A: Particle Density */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-400 font-medium font-outfit">Density Intensity</span>
                <span className="text-[10px] font-mono text-indigo-400 font-semibold uppercase">{density}</span>
              </div>
              <div className="flex gap-1.5 bg-slate-950/60 p-1 rounded-lg border border-white/5">
                {(['light', 'moderate', 'abundant'] as const).map((d) => (
                  <button
                    key={d}
                    id={`adjust-density-${d}`}
                    onClick={() => setDensity(d)}
                    className={`flex-1 py-1 rounded text-[10px] font-mono uppercase tracking-tight transition-all cursor-pointer ${
                      density === d 
                        ? 'bg-gradient-to-r from-blue-500/20 to-indigo-500/20 border border-indigo-500/30 text-indigo-200' 
                        : 'border border-transparent text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    {d === 'light' ? 'Light' : d === 'moderate' ? 'Mod' : 'High'}
                  </button>
                ))}
              </div>
            </div>

            {/* Control B: speed scale multiplier */}
            <div className="space-y-2 flex flex-col justify-center">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-400 font-medium font-outfit">Gravity / Float Velocity</span>
                <span className="text-[10px] font-mono text-indigo-400 font-semibold bg-white/5 px-1.5 py-0.5 rounded">
                  {speedFactor.toFixed(1)}x
                </span>
              </div>
              <div className="flex items-center gap-2 h-7">
                <input
                  type="range"
                  id="adjust-speed-slider"
                  min="0.5"
                  max="2.5"
                  step="0.1"
                  value={speedFactor}
                  onChange={(e) => setSpeedFactor(parseFloat(e.target.value))}
                  className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-blue-400 focus:outline-none"
                />
              </div>
            </div>

          </div>
        </div>

        {/* Dynamic System Status Pill */}
        <div id="pulsing-system-status" className="mt-8 py-3 px-6 bg-white/5 border border-white/10 rounded-full select-none">
          <p className="text-xs text-slate-400 font-mono flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                activeEffect !== 'none' ? 'bg-cyan-400' : 'bg-emerald-400'
              }`} />
              <span className={`relative inline-flex rounded-full h-2 w-2 ${
                activeEffect !== 'none' ? 'bg-cyan-500' : 'bg-emerald-500'
              }`} />
            </span>
            SYSTEM STATUS:{' '}
            <span className={`font-bold uppercase tracking-wider ${
              activeEffect === 'both' ? 'text-purple-400' :
              activeEffect === 'snowflakes' ? 'text-cyan-400' : 
              activeEffect === 'balloons' ? 'text-rose-400' : 'text-emerald-400'
            }`}>
              {activeEffect === 'both' ? 'Winter Celebration Active' :
               activeEffect === 'snowflakes' ? 'Simulating Winter Snow' :
               activeEffect === 'balloons' ? 'Simulating Festive Balloons' : 'Ready'}
            </span>{' '}
            | DURATION: <span className="text-white">5.0s</span> | VIEWPORT: <span className="text-white uppercase">Active</span>
          </p>
        </div>
      </main>

      {/* 5. Sleek Footer Section */}
      <footer id="sleek-footer" className="z-20 p-6 md:p-8 border-t border-white/5 flex flex-col sm:flex-row gap-4 justify-between items-center bg-slate-900/80 backdrop-blur-md">
        <div className="text-xs text-slate-500 font-mono tracking-tight text-center sm:text-left">
          &copy; {new Date().getFullYear()} Atmos Precision Engineering. All rights reserved.
        </div>
        <div className="flex gap-4">
          <div className={`w-2 h-2 rounded-full transition-all duration-500 ${isSnowActive ? 'bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.5)]' : 'bg-slate-700'}`} />
          <div className={`w-2 h-2 rounded-full transition-all duration-500 ${isBalloonActive ? 'bg-rose-400 shadow-[0_0_8px_rgba(251,113,133,0.5)]' : 'bg-slate-700'}`} />
          <div className="w-2 h-2 rounded-full bg-slate-700" />
        </div>
      </footer>

      {/* Embedded subtle visual background assets matching the theme design */}
      <div className="absolute top-1/4 right-[15%] pointer-events-none opacity-[0.08] animate-pulse z-10">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="white" className="text-white">
          <path d="M12 2L14 10H22L15 15L17 23L12 18L7 23L9 15L2 10H10L12 2Z" />
        </svg>
      </div>
      <div className="absolute bottom-[20%] left-[10%] pointer-events-none opacity-[0.05] z-10">
        <div className="w-16 h-20 border-2 border-white rounded-t-full"></div>
      </div>
    </div>
  );
}
